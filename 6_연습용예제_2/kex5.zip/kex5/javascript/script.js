//JavaScript Document 
$(document).ready(function(){
 $(".nav>li").mouseover(function(){
     $(this).children(".submenu").stop().slideDown()
 });
  $(".nav>li").mouseleave(function(){
     $(this).children(".submenu").stop().slideUp()
 });   
    
$('#imgsbar a').click(function(){
    $('#imgsbar a').removeClass('active')
    $(this).addClass('active');
    var imgLeft=$(this).attr('img-left');
    $('#imgs').animate({left:imgLeft},"fast");
 })
   
    
    
    
});


var win;
function winOpen(){
win=window.open('contact.html','child','toolbar=no, location=no, status=no, menubar=no, resizable=no, scrollbars=no, width=500, height=300');    
};